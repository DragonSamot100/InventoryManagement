//package application;
//
//import java.io.IOException;
//import java.sql.SQLException;
//public class test 
//{
//
//	public static void main(String[]args) throws SQLException, ClassNotFoundException, IOException
//	{
////		ArrayList<inventoryItem>shit = new ArrayList<inventoryItem>();
////		shit.add(new inventoryItem("", 2, 2, "", "", ""));
////		menuItem newFood = new menuItem("Potato", "suckShit");
//////		
////		DBController.addMenuItem(newFood.getID(), newFood, 1.2);
//
//		System.out.println(DBController.getMenu().get(0).getName());
//
//		
////	    JdbcDataSource ds = new JdbcDataSource();
////	    ds.setURL("jdbc:h2:./database/management");
////	    ds.setUser("sa");
////	    ds.setPassword("sa");
////	    try {
////	        Connection conn = ds.getConnection();
////	    } catch (SQLException e) {
////	        e.printStackTrace();
////	    }
//	    
//
//	}
//}
